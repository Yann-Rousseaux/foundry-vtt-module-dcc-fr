# foundry-dcc-fr

French translation for the DCC (Dungeon Crawl Classics) system for Foundry Virtual Tabeltop.

## informations

Ce module traduit le système de jeu DCC pour foundry. Il ne traduit pas les compendium du module premier Dungeon crawl classic.

## installation

- Ajouter le module dans foundry via le lien vers le manifest : https://github.com/theksi/foundry-dcc-fr/raw/main/module.json
- Activer dans les options de foundry la langue français

## Crédits
Contributeurs : Mr.Fred (@theksi) et Segoku (@segoku1)

## Changelogs
### 0.0.1
- Initialisation
