# foundry-dcc-fr

French translation for the DCC (Dungeon Crawl Classics) system for Foundry Virtual Tabeltop.

## informations

Ce module traduit le système de jeu DCC pour foundry. Il ne traduit pas les compendium du module premier Dungeon crawl classic.

## installation

- Ajouter le moodule dans foundry via le lien vers le manifest : https://github.com/theksi/foundry-dcc-fr/raw/main/module.json
- Activer dans les options de foundry la langue français

## Crédits
Contributeurs : Mr.Fred (@theksi) et Segoku (@segoku1)

## Changelogs
### 0.1.1
- Validée pour la version 0.34.1 du système de jeu
### 0.0.9
- Couvre la version 0.33.4 du système de jeu DCC
- Traduction des feuilles de types Zero/NPC
- Traduction des feuilles de types Mage
- Traduction des feuilles de types Elfe
- Traduction des feuilles de types Clerc
- Traduction fes feuilles de type voleur
- Traduction des feuilles de type Halfelin
